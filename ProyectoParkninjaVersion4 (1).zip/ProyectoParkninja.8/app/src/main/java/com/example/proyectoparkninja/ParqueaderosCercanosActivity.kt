package com.example.proyectoparkninja

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CustomCap
import com.google.android.gms.maps.model.JointType
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.gms.maps.model.RoundCap
import com.google.firebase.auth.FirebaseAuth
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.math.BigInteger

class ParqueaderosCercanosActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var mMap: GoogleMap
    private val REQUEST_ENABLE_GPS = 123
    private val javeriana = LatLng(4.6284875, -74.0672394)
    private lateinit var parqueaderos: List<Parqueadero>
    private lateinit var auth: FirebaseAuth
    private lateinit var googleMap: GoogleMap
    private lateinit var currentLocation: LatLng // Variable para almacenar la ubicación actual del usuario

    // Agrega tu clave de API de OpenRouteService aquí
    private val API_KEY = "TU_API_KEY"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parqueaderos_cercanos)
        parqueaderos = obtenerListaParqueaderos() // Supongamos que tienes una lista de parqueaderos
        guardarParqueaderos(this, parqueaderos)

        if (!isGPSEnabled()) {
            // Si el GPS no está habilitado, muestra un diálogo para permitir que el usuario lo active
            showEnableGPSDialog()
        }
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val botonPrecios: Button = findViewById(R.id.botonPrecios)
        val Lugar = intent.getStringExtra("Lugar")

        mapFragment.getMapAsync { map ->
            googleMap = map
            if (Lugar != null) {
                centerMapToAddress(Lugar)
            }
        }

        botonPrecios.setOnClickListener() {
            intent = Intent(this, PreciosParqueaderosCercanosActivity::class.java)
            startActivity(intent)
        }
    }

    private fun obtenerUbicacionActual(): LatLng? {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        val location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        return location?.run { LatLng(latitude, longitude) }
    }

    private fun centerMapToAddress(address: String) {
        val geocoder = Geocoder(this)
        try {
            val locationList = geocoder.getFromLocationName(address, 1)
            if (locationList != null && locationList.isNotEmpty()) {
                val location = LatLng(locationList[0].latitude, locationList[0].longitude)

                val cameraUpdate = CameraUpdateFactory.newLatLngZoom(location, 17f) // Ajusta el nivel de zoom según tus preferencias
                googleMap.moveCamera(cameraUpdate)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun isGPSEnabled(): Boolean {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
    }

    private fun showEnableGPSDialog() {
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        startActivityForResult(intent, REQUEST_ENABLE_GPS)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        val parqueaderos = leerParqueaderos(this)
        agregarMarcadoresEnMapa(mMap, parqueaderos, this)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(javeriana, 16f))

        // Obtener la ubicación actual del usuario y establecerla como punto de origen
        currentLocation = obtenerUbicacionActual() ?: LatLng(0.0, 0.0) // Coordenadas de respaldo si no se puede obtener la ubicación

        // Definir el punto de destino
        val destination = LatLng(8.687872, 49.420318) // Puedes ajustar esto según tus necesidades

        try {
            // Pasar el punto de origen y destino al método getDirections
            getDirections(mMap, currentLocation, destination)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getDirections(mMap: GoogleMap, origin: LatLng, destination: LatLng) {
        val originStr = "${origin.latitude},${origin.longitude}"
        val destinationStr = "${destination.latitude},${destination.longitude}"

        val url = "https://api.openrouteservice.org/v2/directions/driving-car?api_key=$API_KEY&start=$originStr&end=$destinationStr"
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) throw IOException("Unexpected code $response")
                    val responseData = response.body?.string()
                    val jsonResponse = JSONObject(responseData)
                    val routes = jsonResponse.getJSONArray("features")
                    val route = routes.getJSONObject(0)
                    val geometry = route.getJSONObject("geometry")
                    val coordinates = geometry.getJSONArray("coordinates")
                    val path = coordinatesToLatLngArray(coordinates)
                    print(path)
                    runOnUiThread {
                        val polylineOptions = PolylineOptions().addAll(path)
                        val polyline = mMap.addPolyline(polylineOptions)
                        stylePolyline(polyline)
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(path[0], 18f))
                    }
                }
            }
        })
    }

    fun coordinatesToLatLngArray(coordinates: JSONArray): ArrayList<LatLng> {
        val path = ArrayList<LatLng>()
        for (i in 0 until coordinates.length()) {
            val coord = coordinates.getJSONArray(i)
            val lat = coord.getDouble(1)
            val lng = coord.getDouble(0)
            path.add(LatLng(lat, lng))
        }
        return path
    }

    private val COLOR_BLACK_ARGB = -0x1000000
    private val POLYLINE_STROKE_WIDTH_PX = 12

    /**
     * Styles the polyline, based on type.
     * @param polyline The polyline object that needs styling.
     */
    private fun stylePolyline(polyline: Polyline) {
        // Get the data object stored with the polyline.
        val type = polyline.tag?.toString() ?: ""
        when (type) {
            "A" -> {
                // Use a custom bitmap as the cap at the start of the line.
                polyline.startCap = CustomCap(
                    BitmapDescriptorFactory.fromResource(com.google.android.material.R.drawable.abc_ic_arrow_drop_right_black_24dp), 10f)
            }
            "B" -> {
                // Use a round cap at the start of the line.
                polyline.startCap = RoundCap()
            }
        }
        polyline.endCap = RoundCap()
        polyline.width = POLYLINE_STROKE_WIDTH_PX.toFloat()
        polyline.color = COLOR_BLACK_ARGB
        polyline.jointType = JointType.ROUND
    }
}
