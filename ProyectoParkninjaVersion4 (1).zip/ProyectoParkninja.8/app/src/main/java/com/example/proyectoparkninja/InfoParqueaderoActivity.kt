package com.example.proyectoparkninja

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class InfoParqueaderoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info_parqueadero)
    }
}